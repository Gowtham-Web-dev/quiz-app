let questions = [
  {
  numb: 1,
  question: "What component is used to compile java programs?",
  answer: "JVM",
  options: [
    "JRE",
    "JIT",
    "JDK",
    "JVM"
  ]
},
  {
  numb: 2,
  question: "Which is not a method in applet life cycle?",
  answer: "main()",
  options: [
    "start()",
    "destroy()",
    "stop()"  ,
    "main()"
  ]
},
  {
  numb: 3,
  question: "Which class handles the exception  thrown when divided by zero statement is executed?",
  answer: "ArithmeticException",
  options: [
    "NumberFormatException",
    "ArithmeticException",
    "NullpointerException",
    "DividedByZeroException"
  ]
}
  
    //dense array
];
