let questions = [
    {
    numb: 1,
    question: "Why is CPU scheduling done?",
    answer: "Increase CPU utilization",
    options: [
      "Decrease CPU Utilization",
      "Increase CPU utilization",
      "Keep the CPU more idle",
      "Decrease CPU cost"
    ]
  },
    {
    numb: 2,
    question: "Main memory of a computer system is ?" ,
    answer: "Volatile",
    options: [
      "Non-Volatile",
      "Volatile",
      "Restricted",
      "Unrestricted"
    ]
  },
    {
    numb: 3,
    question: "Which of the following mechanism is a locking mechanism?",
    answer: "Mutex",
    options: [
      "Semaphore",
      "PCB",
      "Binary Semaphore",
      "Mutex"
    ]
  },
   
      //dense array
  ];
  