let questions = [
  {
  numb: 1,
  question: "Bluetooth is a example of",
  answer: "Personal Area Network",
  options: [ 
    "Wide Area Network",
    "Local Area Network",
    "Personal Area Network",
    "Virtual Private Network"
  ]
},
  {
  numb: 2,
  question: "Parity bits are used for which of the following purposes?",
  answer: "To detect errors",
  options: [
    "Encryption of Data",
    "To transmit faster",
    "To detect errors",
    "To identify the user"
  ]
},
  {
  numb: 3,
  question: "Which Network topology requires a central controller or hub?",
  answer: "Star",
  options: [
    "Ring",
    "Bus",
    "Star",
    "Mesh"
  ]
}
 

  
];
