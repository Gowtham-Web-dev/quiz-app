let questions = [
  {
  numb: 1,
  question: "Which among the following is mutable data structure?",
  answer: "set",
  options: [
    "set",
    "int",
    "str",
    "tuple"
  ]
},
  {
  numb: 2,
  question: "What is Pickling in Python?" ,
  answer: "Conversion of a python object hierarchy into byte stream",
  options: [
    "Conversion of a datatable into a list",
    "Conversion of a list into a database",
    "Conversion of a byte stream into python object hierarchy",
    "Conversion of a python object hierarchy into byte stream"
  ]
},
  {
  numb: 3,
  question: "Who is the creator of Python?",
  answer: "Guido Van Rossum",
  options: [
    "Guido Van Rossum",
    "Wick Van Rossum",
    "Van dar dusa",
    "Rasmus Lerdorf"
  ]
},
  
  //dense array
];
