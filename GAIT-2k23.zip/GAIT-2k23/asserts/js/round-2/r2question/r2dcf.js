let questions = [
    {
    numb: 1,
    question: "What is the purpose of BIOS in a computer?",
    answer: "Initialize hardware and boot the opertating system",
    options: [
      "Execute application programs ",
      "manage RAM, ROM & USB Port",
      "Initialize hardware and boot the opertating system",
      "manage file storage"
    ]
  },
    {
    numb: 2,
    question: "In Computer memory hierarchy, Which type of memory is the faster but also the smallest in capacity?" ,
    answer: "Cache Memory",
    options: [
      "Cache Memory",
      "RAM",
      "Hard disk drive",
      "optical disk"
    ]
  },
    {
    numb: 3,
    question: "If you have two NOT gates in series (one after the other),What is the overall effect?",
    answer: "It acts as a buffer",
    options: [
      "Its acts as an AND gate",
      "Its acts as an OR gate",
      "It inverts the input",
      "It acts as a buffer"
    ]
  }  //dense array
  ];
  