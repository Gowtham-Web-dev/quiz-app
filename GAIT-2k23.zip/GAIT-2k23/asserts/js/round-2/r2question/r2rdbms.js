let questions = [
  {
  numb: 1,
  question: "To remove a table from a database, What command is used? ",
  answer: "Drop",
  options: [
    "Drop",
    "Alter",
    "Remove",
    "Delete"
  ]
},
  {
  numb: 2,
  question: "______ will undo all statements upto commit?",
  answer: "Roll Back",
  options: [
    "Abort",
    "Transaction",
    "Flash Back",
    "Roll Back"
  ]
},
  {
  numb: 3,
  question: "Which among the following is not RDBMS?",
  answer: "MangoDB",
  options: [
    "SQL",
    "MangoDB",
    " MySQL",
    "MariaDB"
  ]
},

      //dense array
];
