let questions = [
  {
    numb: 1,
    question: "Which of the following is symbol is used to declare the preprocessor directives in C++?",
    answer: "#",
    options: [
      "$",
      "^",
      "#",
      "*"
  ]
},
  {
  numb: 2,
  question: "Which operator has ?: symbol?",
  answer: "Ternary",
  options: [
    "Unary",
    "Binary",
    "Ternary",
    "None"
  ]
},
  {
  numb: 3,
  question: "A function that is automatically invoked when object goes out of scope___________",
  answer: "Destructor",
  options: [
    "Destructor",
    "Constructor",
    "Overloading",
    "virtual"
  ]
}

//dense array
];
