let questions = [
    {
    numb: 1,
    question: "I'm the heart of your computer,but don't have a heart beat.What am I?",
    answer: "CPU",
    options: [
   "CPU",
   ]
  },
    {
    numb: 2,
    question:"The more you code,the more of me there is I may be gone for now but you can't get rid of me forever.Who am I?",
    answer: "A Bug",
    options: [
      "A Bug",
    ]
  },
    {
    numb: 3,
    question: "As a Developer I'm your eyes,Showing you the result of your code in your language of choice,Who am I?",
    answer: "Print Statement",
    options: [
      "Print Statement",
    ]
  },
    {
    numb: 4,
    question: "As a developer,you usually get mad at me beacuse I complain a lot,Although,I'm usually right,What am I? ",
    answer: "Compiler",
    options: [
      "Compiler" ,
    ],
  },
    {
    numb: 5,
    question: " When you give me opposite input i give one as output ,Who am I?",
    answer: "Exclusive OR gate",
    options: [
      "Exclusive OR gate"
    ]
  },    //dense array
  {
    numb: 6,
    question: "What do computer programmer sing in shower?",
    answer: "Disc-O",
    options: [
      "Disc-O"
    ]
  }, 
    {
    numb: 7,
    question: "I am a type of computer network  that is used to connect device in a small area such as a home or office ,What am I?",
    answer: "LAN-Local Area Network",
    options: [
      "LAN-Local Area Network"
    ]
  }
 

];
