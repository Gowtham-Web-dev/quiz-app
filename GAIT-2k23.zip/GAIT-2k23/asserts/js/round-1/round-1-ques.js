let questions = [
    {
    numb: 1,
    question:"What does the acronym GPT Stands for in ChatGPT?",
    answer: "Generative Pre-trained Transformer",
    options: [
   "Generative Pre-trained Transformer",
   ]
  },
    {
    numb: 2,
    question:"Crypto currency is based on what basic technology?",
    answer: "Blockchain",
    options: [
      "Blockchain",
    ]
  },
    {
    numb: 3,
    question: "The India's Ministry of Education has chosen oracle cloud infrastructure to modernize which national education technology platform?",
    answer: "DIKSHA (Digital Infrastructure for lnowledge sharing",
    options: [
      "DIKSHA (Digital Infrastructure for knowledge sharing)",
    ]
    },
    
    {
    numb: 4,
    question: "World Wide Web Day is celebrated on  ______ every year ",
    answer: "August 1",
    options: [
      "August 1" ,
    ],
  },
    {
    numb: 5,
    question: " In day-to-day life we are using USB. Who is the founder of USB?",
    answer: "Ajay V.Bhatt (1996)",
    options: [
      "Ajay V.Bhatt (1996)"
    ]
  },    //dense array
  {
    numb: 6,
    question: "The combination of GPS & _______ tags are used by the Indian Railways for tracking of wagons, coaches and locomotives to ensure the effective and transparent functioning of the system?",
    answer: "RFID (Radio Frequency Identification tag)",
    options: [
      "RFID (Radio Frequency Identification tag)"
    ]
  }, 
    {
    numb: 7,
    question: "Recently Jio has tie up with _________ to build state-of-the-art AI super computer in India.",
    answer: "NVIDIA",
    options: [
      "NVIDIA"
    ]
  },  
   {
    numb: 8,
    question: "Who has become India's first regional AI news anchor?",
    answer: "LISA",
    options: [
      "LISA",
    ]
  },  
   {
    numb: 9,
    question: "Chorme is getting a new look as it celebrates its 15th anniversary, with the focus on ______ design?",
    answer: "Material you",
    options: [
      "Material you"
    ]
  },  
   {
    numb: 10,
    question: "Hitachi Payment Service Collabrated with Natioanl Payment Corporation of India and launched India's first ______ ATM for cardless & netfree transaction",
    answer: "UPI (Unified Payment Interface)",
    options: [
      "UPI (Unified Payment Interface)"
    ]
  }

];
